
var clearInput = function () {
    document.getElementById('inputBox').value = null;

}

var addNumberTo = function() {
let inputText = document.getElementById('inputBox').value;
document.getElementById('result').innerText = inputText; 
clearInput();
}

var subtractNum = function(){
let inputText = document.getElementById('inputBox').value;
let currentNumber = document.getElementById('result').innerText;
let result = currentNumber - inputText;
document.getElementById('result').innerText = result; 
clearInput();
}
//alert(inputText)
//alert('Working');}


var addNum = function(){
var inputText = document.getElementById('inputBox').value
let currentNumber = document.getElementById('result').innerText;
let result = parseInt(currentNumber) + parseInt(inputText);
document.getElementById('result').innerText = result; 
clearInput();
    
}

var multiplyNum = function(){
var inputText = document.getElementById('inputBox').value
let currentNumber = document.getElementById('result').innerText;
let result = parseInt(currentNumber * inputText);
document.getElementById('result').innerText = result; 
clearInput();
    
}

var divideNum = function(){
var inputText = document.getElementById('inputBox').value
let currentNumber = document.getElementById('result').innerText;
let result = currentNumber / inputText;
document.getElementById('result').innerText = result; 
clearInput();
    
}

var squareRootNum = function(){
var inputText = document.getElementById('inputBox').value
let currentNumber = document.getElementById('result').innerText;
let result = Math.sqrt(currentNumber);
document.getElementById('result').innerText = result; 
clearInput();
    
}

document.getElementById('subtract').addEventListener('click', subtractNum)
document.getElementById('add').addEventListener('click', addNum)
document.getElementById('multiply').addEventListener('click', multiplyNum)
document.getElementById('divide').addEventListener('click', divideNum)
document.getElementById('squareRoot').addEventListener('click', squareRootNum)
document.getElementById('start').addEventListener('click', addNumberTo)

//var currentInput = document.getElementById('inputBox');