Made by: Darius Rain
Day: 33
Date: 11/29/19

-----------------------------------------------How to use-----------------------------------------------------------

**RULES FOR THE '.item_prices_config.txt' file located in the current directory of the program.**
**[To access the '.item_prices_config.txt' file use the following command 'ls -a' to list then 'nano .items_prices_config.txt' or open your file manager click on show hidden files then open the file in any text editor and edit it]**
(Can actually use this concept to take any item and price not just fruit.)
DO NOT DELETE! : 'START' and 'END'.
NO SPACES BETWEEN LISTED ITEMS AND PRICES!
EXAMPLE: (Will use this as default for my program ~ feel free to change the code.)
*******************************************************************************************************************
START
Apples 0.44
Oranges 0.67
Pears 0.43
Grapes 1.25
Blueberries 1.00
Mangos 1.73
Watermelon
END
*******************************************************************************************************************



Syntax: 
*******************************************************************************************************************
START
item price
item price
item price
item price
item price
item price
item price
END
*******************************************************************************************************************
