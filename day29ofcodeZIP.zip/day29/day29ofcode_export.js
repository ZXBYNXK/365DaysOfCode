//Name: Darius Rain
//Date: 11-24-24
//Day: 29
//Misson: Import and export a javascript file, and use it an another file.
const myModule = function() {
    console.log("Imported")
}
module.exports = myModule

