//Name: Darius Rain
//Date: 11-24-24
//Day: 29
//Misson: Import and export a javascript file, and use it an another file.
const importMyModule = require('./day29ofcode_export')
importMyModule()

//myModule.mainObject.methods.addPerson("Name", "Age(23)");
