let limit = 10,
count = 0,
prevNum;

function fibinachi(num){
   prevNum = num
   
        

        
    }
    
}

//0       1     1    2     3  5     8      13      21
//\ + / = |\ + /  +=  |\ + / = |\ + / = |\ + /|   =  |+   |
fibinachi(1)