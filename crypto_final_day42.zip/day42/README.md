Project Name: Crypto (DAY 42 ~ 365 Days of code challenge.)

Made by: Darius Rain (Newbie)

Date: 12/7/19
_________________________________________________________________________________________________________________________________
Code used: Javascript
Dependencies: Node.js (YOU NEED "Node.js" ON YOUR COMPUTER TO USE THIS PROGRAM)
_________________________________________________________________________________________________________________________________
How to use:

    To encrypt a message:
       
        Step 1: Go to terminal and change to the directory where this ("crypto_final_day42.js") program is stored.
        Step 2: Type "node crypto_final_day42.js" (You should see a menu for the program)
        Step 3: Choose option 1 in the program's menu (Should see - "Write message here, or paste:")
              After submiting the message(Should see - Encryption complete! | Files have been renewed: "encrypted_message.txt", "decryption_key.txt".)
        Step 4: To access the encrypted message open the file named "encrypted_message.txt" and the text should be there.
              To access the key for the encrypted message open the file named "decryption_key.txt".
              
        Now what? 
            Now you or anyone can decrypt your message ONLY WITH THIS PROGRAM. So for another person to read your message THEY WOULD HAFT TO DOWNLOAD THIS PROGRAM. And decrypt it using option 2 in the program. (SEE "To Decrypt a message below if you dont understand");
                     
     To decrypt a message:
        
        Step 1: Go to terminal and change to the directory where this ("crypto_final_day42.js") program is stored.
        Step 2: Type "node crypto_final_day42.js" (You should see a menu for the program)
        Step 3: Choose option 2 in the program's menu (Should see first - "Copy & paste message to decrypt:") - paste encrypted message then (Should see second: "Copy & paste key for encrypted message")
        Step 4: Then you should see the message at the bottom of them program's main menu.
        
        What if?
            What if message isnt unencrypted: 1.The program had an error |2.The key or message isnt right |3. A copy paste mistake(SOMETIMES UNWANTED SPACES ARE ADDED AFTER PASTING.) <--NOTE: The encyption does have spaces in it naturally so make sure it isnt part of the encrypted message or just an added space(Can check by simply not deleteing the space and run the decryption the first time and the second time vice versa.). 
        
      How to send message to someone?
        First they would need this program installed to decrypt any message.(NOTE: Before they do, make sure they install node on their system)
        Second send them the encrypted message and then the key to access it ~ (Preferably you should'nt send the key on the same messaging application you sent the encrypted message).
        Then tell them to follow the same steps written in the above "To decrypt a message" guide.
             
_________________________________________________________________________________________________________________________________  

THANKS FOR USING MY PROGRAM AND READING MY README ~ Darius Rain
_________________________________________________________________________________________________________________________________  
